const express = require('express');
const cors = require('cors');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Dummy Data
const energyData = {
  currentConsumption: 530,
  energySaved: 145,
  consumptionTrend: [420, 450, 490, 510, 530],
};

const leaderboard = [
  { name: 'User A', score: 160 },
  { name: 'User B', score: 135 },
  { name: 'User C', score: 105 },
];

// Routes
app.get('/api/energy', (req, res) => {
  res.json(energyData);
});

app.post('/api/anomalies', (req, res) => {
  console.log('Anomaly received:', req.body);
  res.status(200).json({ message: 'Anomaly recorded.' });
});

app.get('/api/leaderboard', (req, res) => {
  res.json(leaderboard);
});

// Start Server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
