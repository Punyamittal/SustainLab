import React, { useEffect, useState } from 'react';

interface User {
  name: string;
  score: number;
}

const Leaderboard: React.FC = () => {
  const [users, setUsers] = useState<User[]>([
    { name: 'User A', score: 150 },
    { name: 'User B', score: 120 },
    { name: 'User C', score: 90 },
  ]);

  useEffect(() => {
    // Simulate fetching leaderboard data from an API
  }, []);

  return (
    <div className="leaderboard">
      <h2>Community Leaderboard</h2>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Score</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user, idx) => (
            <tr key={idx}>
              <td>{user.name}</td>
              <td>{user.score}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Leaderboard;

