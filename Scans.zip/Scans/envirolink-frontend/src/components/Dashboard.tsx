import React, { useEffect, useState } from 'react';
import { fetchEnergyData } from '../api/dataService';

interface EnergyData {
  currentConsumption: number;
  energySaved: number;
  consumptionTrend: number[];
}

const Dashboard: React.FC = () => {
  const [data, setData] = useState<EnergyData | null>(null);

  useEffect(() => {
    const getData = async () => {
      const result = await fetchEnergyData();
      setData(result);
    };
    getData();
  }, []);

  if (!data) return <div>Loading...</div>;

  return (
    <div className="p-6 bg-white rounded-xl shadow-md space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-blue-600 mb-2">Energy Overview</h2>
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-blue-50 p-4 rounded-lg text-center">
            <p className="text-lg font-semibold text-gray-700">Current Consumption</p>
            <p className="text-3xl font-bold text-blue-700">{data.currentConsumption} kWh</p>
          </div>
          <div className="bg-green-50 p-4 rounded-lg text-center">
            <p className="text-lg font-semibold text-gray-700">Energy Saved Today</p>
            <p className="text-3xl font-bold text-green-700">{data.energySaved} kWh</p>
          </div>
        </div>
      </div>

      <div>
        <h3 className="text-xl font-semibold text-gray-800 mb-2">Consumption Trend</h3>
        <ul className="space-y-2">
          {data.consumptionTrend.map((value, index) => (
            <li
              key={index}
              className="flex justify-between bg-gray-100 p-3 rounded-md shadow-sm"
            >
              <span>Hour {index + 1}</span>
              <span className="font-medium text-gray-700">{value} kWh</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default Dashboard;


