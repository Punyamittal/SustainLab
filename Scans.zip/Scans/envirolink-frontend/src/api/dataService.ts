export const fetchEnergyData = async () => {
    return Promise.resolve({
      currentConsumption: 530,
      energySaved: 145,
      consumptionTrend: [420, 450, 490, 510, 530],
    });
  };
  