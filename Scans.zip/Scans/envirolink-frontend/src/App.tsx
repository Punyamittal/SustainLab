import React from 'react';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import Leaderboard from './components/Leaderboard';
import './styles/App.css';

const App: React.FC = () => {
  return (
    <div className="App">
      <Header />
      <main className="main">
        <section className="section dashboard-section">
          <Dashboard />
        </section>
        <section className="section leaderboard-section">
          <Leaderboard />
        </section>
      </main>
    </div>
  );
};

export default App;


